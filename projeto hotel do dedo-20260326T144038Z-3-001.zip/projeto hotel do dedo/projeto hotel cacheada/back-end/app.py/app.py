import os
from flask import Flask, send_from_directory

app = Flask(__name__)

#caminho base do projeto (uma pasta acima do backend)
 BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__),".."))

FRONTED_DIR = os.path.join(BASE_DIR,"frontend")
@app.route("/")
def home():
   return "bom dia cacheada!"

app.run()